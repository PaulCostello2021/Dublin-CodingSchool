<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');

}


?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <link rel = "stylesheet" href="style.css">
    
    <title> Quiz Website</title>
</head>
<body>
    <main class='main' >
    <!-- <header class='header' >
            <a href="#" class='logo'>Quiz.</a>

            <nav class ='navbar'>
                <a href="QuizWebsite.html" class='active'>Home</a>
                <a href="About.html" class="active">About</a>
                <a href="Services.html" class="active" >Services</a>
                <a href="contact.html" class="active ">Contact</a>
            </nav>

        </header> -->
       
        <div class="container">
            <section class="quiz-section">
                <div class="quiz-box">
                    <h1>CuriSTEAM Quiz</h1>
                    <div class="quiz-header">
                        <span>Quiz Website Tutorials</span>
                        <span class="header-score">Score: 0 / 5</span>
                    </div>

                    <h2 class="question-content">What does HTML stand for?</h2>
                    <div class="option-list">
                        <div class="option">
                            <span>A. Hyper Type Multi Language</span>
                        </div>
                        <div class="option">
                            <span>B. Hyper Text Multiple Language</span>
                        </div>
                        <div class="option">
                            <span>C. Hyper Test Markup Language</span>
                        </div>
                        <div class="option">
                            <span>D.Home Text Multi Language</span>
                            </div>
                         </div>
        
                         <div class="quiz-footer">
                            <span class="question-total">1 of 5 Questions</span>
                            <button class="next-btn" >Next</button>
                         </div>
                      </div>

                      <div class="result-box">
                        <h2>Well done <br><?php echo $_SESSION['username'];?> <br> Your Score Is. </h2>
                        <div class="percentage-container">
                            <div class="circular-progress">
                                <span class="progress-value">0%</span>

                            </div>
                               <span class="score-text">Your Score 0 out of 5</span>
                        </div>
                         <div class="buttons">
                            <button class="tryAgain-btn">Try Again</button>
                            <button class="goHome-btn">Go To Home</button>
                         </div>
                      </div>
               </section>

    <section class="home">
        <div class="home-content">
            <h1 class="welcome-1">

             Welcome <br> <?php echo $_SESSION['username'];?>

            </h1>
            <p>Are you ready to test your computer science knowledge. Click the start quiz button to begin.</p>
            <button class="start-btn">Start Quiz</button>
            <button class="start-btn"><a href="sign.php"> Logout</a></button>

           

        </div>
    </section>
</div>
    </main>

    <div class="popup-info">

        <h2>Quiz Guide</h2>
        <span class="info">1. Answer all questions to the best of your ability</span>
        <span class="info">2. Try not to guess the answer</span>
        <span class="info">3. Make note of any questions you answer incorrectly</span>
        <span class="info">4. You will be marked out of the best of five</span>
        <span class="info">5. You will be given a precentage out of 100%</span>
        
        <div class="btn-group">
            <button class="info-btn exit-btn">Exit Quiz</button>
            <a href="#" class="info-btn continue-btn">Continue</a>

        </div>

    </div>

    <script src="questions.js" ></script>
    <script src="script.js"></script>
</body>
</html>