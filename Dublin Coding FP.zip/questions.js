let questions = [
    {
        numb: 1,
    
        question: "What does HTML stand for?",
        answer: "C. Hyper Text Markup Language",
        options: [
            "A. Hyper Type Multi Language",
            "B. Hyper Text Multiple Language",
            "C. Hyper Text Markup Language",
            "D. Home Text Multi Language"
        ]
    },
    {
        numb: 2,
        question: "What does SQL stand for?",
        answer: "D. Structured Query Language",
        options: [
            "A. Strength Query Language",
            "B. Stylesheet Query Language",
            "C. Some Query Language",
            "D. Structured Query Language"
        ]
    },
    {
        numb: 3,
        question: "What does PHP stand for?",
        answer: "D. Programming Hypertext Preprocessor",
        options: [
            "A. Hypertext Preprocessor",
            "B. Hometext Programming",
            "C. Hypertext Preprogramming",
            "D. Programming Hypertext Preprocessor"
        ]
    },
    {
        numb: 4,
        question: "What does URL stand for?",
        answer: "A. Universal Resource Locator",
        options: [
            "A. Universal Resource Locator",
            "B. Unique Reference Locator",
            "C. User Retention Loop",
            "D. Ubiquitous Retrieval Link"
        ]
    },
    {
        numb: 5,
        question: "What does CSS stand for?",
        answer: "A. Cascading Style Sheet",
        options: [
            "A. Cascading Style Sheet",
            "B. Cute Style Sheet",
            "C. Computer Style Sheet",
            "D. Curious Style Sheet"
        ]
    }
];
